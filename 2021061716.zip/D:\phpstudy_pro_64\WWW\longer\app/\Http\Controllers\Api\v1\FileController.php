<?php

namespace App\Http\Controllers\Api\v1;

use Illuminate\Http\JsonResponse;

class FileController extends BaseController
{
    /**
     * todo:获取文件列表
     * @return JsonResponse
     */
    public function getFileLists()
    {
        validatePost($this->post, ['path'=>'required|string', 'basename'=>'required|string']);
        $result = $this->fileService->getFileLists($this->post, ['rebar3']);
        return ajaxReturn($result);
    }

    /**
     * todo:读取文件内容
     * @return JsonResponse
     */
    public function readFile()
    {
        validatePost($this->post, ['path'=>'required|string']);
        $result = $this->fileService->readFile($this->post);
        return ajaxReturn($result);
    }

    /**
     * todo:文件更新
     * @return JsonResponse
     */
    public function updateFile()
    {
        validatePost($this->post, ['path'=>'required|string', 'content' => 'required|string']);
        $result = $this->fileService->updateFile($this->post);
        return ajaxReturn($result);
    }

    /**
     * TODO:：文件打包
     * @param string path 文件路径
     * @param string resource 打包后文件前缀
     * @param array docLists 资源列表
     * @return JsonResponse
     */
    public function gZipFile()
    {
        validatePost($this->post, ['path'=>'required|string','resource'=>'required|string','docLists'=>'required|array']);
        $result = $this->fileService->gZipFile($this->post);
        return ajaxReturn($result);
    }
}
