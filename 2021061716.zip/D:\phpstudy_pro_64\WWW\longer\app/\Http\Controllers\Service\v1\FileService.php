<?php

namespace App\Http\Controllers\Service\v1;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Utils\Code;
use Illuminate\Http\Request;

class FileService extends BaseService
{
    /**
     * @var static $instance
     */
    private static $instance;
    /**
     * @return static
     */
    public static function getInstance()
    {
        if (!self::$instance instanceof self) {
            self::$instance = new static();
        }
        return self::$instance;
    }

    /**
     * todo:获取文件列表
     * @param $form
     * @param array $permission
     * @return array
     */
    public function getFileLists($form, array $permission = [])
    {
        $this->return['lists'] = getFileLists(getFilePath($form['path'], $form['basename']), $permission);
        return $this->return;
    }

    /**
     * todo：获取文件内容
     * @param $form
     * @return array|string
     */
    public function readFile($form)
    {
        if (!file_exists($form['path'])) {
            $this->return['code'] = Code::ERROR;
            $this->return['message'] = 'File does not exist';
        }
        if (filesize($form['path']) > 1024 * 1024 * 3) {
            $this->return['code'] = Code::ERROR;
            $this->return['message'] = 'File size exceeds limit';
        }
        $result = getFileContent($form['path']);
        !empty($result['code']) ?  $this->return = $result : $this->return['lists'] = $result;
        return $this->return;
    }

    /**
     * todo:写入文件内容
     * @param $form
     * @return array|int
     */
    public function updateFile($form)
    {
        if (!file_exists($form['path'])) {
            $this->return['code'] = Code::ERROR;
            $this->return['message'] = 'File does not exist';
        }
        $result = writeFile($form['path'], $form['content']);
        !empty($result['code']) ?  $this->return = $result : $this->return['lists'] = $form;
        return $this->return;
    }

    /**
     * todo:文件打包
     * @param $form
     * @return array|bool
     */
    public function gZipFile($form)
	{
        if (!file_exists($form['path'])) {
            $this->return['code'] = Code::ERROR;
            $this->return['message'] = 'File does not exist';
        }
        $result = gZipFile($form['docLists'], $form['path'], $form['resource'].'_'.date('YmdHis').'.zip');
        !empty($result['code']) ?  $this->return = $result : $this->return['lists'] = $form;
        return $this->return;
	}
}
